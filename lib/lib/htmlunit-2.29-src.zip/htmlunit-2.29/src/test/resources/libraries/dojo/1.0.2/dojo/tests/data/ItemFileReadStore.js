if(!dojo._hasResource["tests.data.ItemFileReadStore"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["tests.data.ItemFileReadStore"] = true;
dojo.provide("tests.data.ItemFileReadStore");
dojo.require("tests.data.readOnlyItemFileTestTemplates");
dojo.require("dojo.data.ItemFileReadStore");

tests.data.readOnlyItemFileTestTemplates.registerTestsForDatastore("dojo.data.ItemFileReadStore");


}
