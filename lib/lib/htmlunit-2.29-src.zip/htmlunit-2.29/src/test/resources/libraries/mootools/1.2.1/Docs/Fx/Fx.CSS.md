Class: Fx.CSS {#Fx-CSS}
=======================

CSS parsing class for effects. Required by [Fx.Tween][], [Fx.Morph][], [Fx.Elements][].

Has no public methods.



[Fx.Tween]: /Fx/Fx.Tween
[Fx.Morph]: /Fx/Fx.Morph
[Fx.Elements]: /Plugins/Fx.Elements